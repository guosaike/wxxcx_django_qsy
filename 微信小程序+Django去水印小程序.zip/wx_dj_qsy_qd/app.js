App({
    onLaunch() {
        const n = wx.getStorageSync("logs") || [];
        n.unshift(Date.now()), wx.setStorageSync("logs", n), wx.login({
            success: n => {}
        });
    },
    globalData: {
        userInfo: null,
        // default:'http://127.0.0.1:8000'
        default:'https://akqsy.ake999.com'
    }
});
!function() {
    var app = getApp()
    let chaping_ad = null;
    Page({
        data: {
            isInput: 0,
            inputValue: "",
            lbtlist: [],
            gg: "",
            animation: null,
            banner_ad: ""
        },
        timer: null,
        bindinput(e) {
            var t = e.detail.value;
            t.length > 0 && this.setData({
                isInput: 1,
                inputValue: t
            });
        },
        saveCache(e) {
            let t = wx.getStorageSync("analysis");
            t || (t = []), t.length >= 50 && t.splice(0, 1), t.push(e), wx.setStorageSync("analysis", t);
        },
        paste_and_content() {
            console.log("观看激励视频，再解析");
            let e = this;
            wx.getClipboardData({
                success(t) {
                    if (console.log("解析内容", t.data), !t.data) return wx.showToast({
                        title: "请输入视频 (或图集) 链接",
                        icon: "none",
                        duration: 2e3
                    }), !1;
                    e.qushuiyin("", t.data);
                }
            });
        },
        paste : function() {
          var t = {
              MryTz: "粘贴成功，请点击 '解析' ",
              sKKmC: "请复制视频分享链接",
              Zsqnz: "获取剪贴板失败"
          }, e = t, o = this;
          wx.getClipboardData({
              success: function(t) {
                  var n = o.fetchUrl(t.data);
                  if (o.isUrl(n)) {
                      var a = {};
                      a.pageUrl = n, a.showCircle = !0, o.setData({
                        inputValue: n,
                    });
                  } else {
                      var s = {
                          input_show: !0
                      };
                      o.setData(s);
                      var r = {};
                      r.title = e.sKKmC, r.icon = "none", r.duration = 1e3, wx.showToast(r);
                  }
              },
              fail: function() {
                  console.log(e.Zsqnz);
              }
          });
      },
          //检查输入框是否为链接
      isUrl: function(t) {
        return !!t && (t.startsWith("http://") || t.startsWith("https://"));
      },
      //过滤字符串中的URL
      fetchUrl: function(t) {
        var o = /(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:\/~\+#!\$\(\)\\|]*[\w\-\@?^=%&\/~\+#!\$\(\)\\|])?/,
          a = t.match(o);
        return a ? a[0] : null;
      },
        qushuiyin(e, t) {
            let a = this;
            wx.showLoading({
                title: "解析中..."
            });
            let s = t || a.data.inputValue;
            console.log("一键去水印", s),
             wx.request({
                // url: "https://api.wxshares.com/api/qsy/as",
                url: app.globalData.default + '/api/qsy/',
                data: {
                    // key: "AgXekUnrHrvUdyINUBEhSbmIvJ",
                    url: s
                },
                header: {
                    "content-type": "application/json"
                },
                success(e) {
                    wx.hideLoading(), console.log("服务器返回数据", e.data);
                    let t = e.data;
                    console.log(e.data)
                    200 == t.code ? (console.log("解析成功打印数据", t.data),
                     wx.navigateTo({
                        url: "/pages/analysis/analysis",
                        events: {
                            acceptDataFromOpenedPage: function(e) {
                                console.log(e);
                            },
                            someEvent: function(e) {
                                console.log(e);
                            }
                        },
                        success: function(e) {
                            a.setData({
                                inputValue: "",
                                isInput: 0
                            }),
                             a.saveCache(s), 
                             e.eventChannel.emit("acceptDataFromOpenerPage", {
                                data: t
                            });
                        }
                    })) : wx.showModal({
                        title: "解析失败",
                        content: "解析失败，可能是因为：1、链接错误或暂时不支持平台2、作品还未审核通过3、作品已经被删除了---如有问题，请联系我们的客服【python_kk】",
                        success(e) {
                            e.confirm && a.copyBtn(1, "python_kk");
                        }
                    });
                }
            });
        },
        clear() {
            this.setData({
                inputValue: "",
                isInput: 0
            });
        },
        copyBtn(e, t) {
            let a = t || e.target.dataset.kefu;
            wx.setClipboardData({
                data: a,
                success: function(e) {
                    wx.showToast({
                        title: "【客服微信】复制成功",
                        icon: "none",
                        mask: "true"
                    });
                }
            });
        },
        onUnload(){
          this.timer && clearInterval(this.timer)
        },
        onLoad() {
            this.gg_ad()
            this.lbt()
            this.gg()
            wx.getUserProfile && this.setData({
                canIUseGetUserProfile: !0
            });


            const query = wx.createSelectorQuery()
            query.select('.clip-text').boundingClientRect()
            query.exec(res => {
              const scrollWidth = Number(this.data.gg.length * 12)
              // 如果文本长度小于容器宽度，不滚动
              if (scrollWidth < res[0].width) return
  
              const animation = wx.createAnimation({
                duration: 10000,
                delay: 1000,
              })
              animation.translateX(-scrollWidth).step()
              this.setData({
                animation: animation.export()
              })
  
              this.timer = setInterval(() => {
                animation.translateX(0).step({ duration: 0 })
                animation.translateX(-scrollWidth).step({ duration: 10000 })
                this.setData({
                  animation: animation.export()
                })
              }, 10000)});

        },
        getUserProfile(e) {
            wx.getUserProfile({
                desc: "展示用户信息",
                success: e => {
                    console.log(e), this.setData({
                        userInfo: e.userInfo,
                        hasUserInfo: !0
                    });
                }
            });
        },
        getUserInfo(e) {
            console.log(e), this.setData({
                userInfo: e.detail.userInfo,
                hasUserInfo: !0
            });
        },
        lbt() {
          let a = this;
          wx.request({
            url: app.globalData.default + '/api/lbt/',
                header: {
                    "content-type": "application/json"
                },
                success: (res) =>{
                  // console.log(res.data)
                  a.setData({
                    lbtlist: res.data.lbt,
                  })
                },

          })
        },
        gg() {
          let a = this;
          wx.request({
            url: app.globalData.default + '/api/gg/',
                header: {
                    "content-type": "application/json"
                },
                success: (res) =>{
                  // console.log(res.data.gg[0]),
                  a.setData({
                    
                    gglist: res.data.gg[0],
                  })
                },
          })
        },
        gg_ad() {
          let b = this;
          wx.request({
            url: app.globalData.default + '/api/gg_ad/',
                header: {
                    "content-type": "application/json"
                },
                success: (res) =>{
                  // console.log(res.data.llz[0]),
                  b.setData({
                    banner_ad: res.data.llz[0],
                  })
                  // 插屏广告因为只展现在 js 文件中 不写 wxml 所以需要通过wx.request直接赋值chaping_ad广告代码
                  chaping_ad = res.data.llz[2]
                  // console.log(chaping_ad)
                  let e = null;
                  if(chaping_ad.length>10){
                      wx.createInterstitialAd && (e = wx.createInterstitialAd({
                          adUnitId: chaping_ad
                      }), e.onLoad(() => {}), e.onError(e => {}), e.onClose(() => {})), e && e.show().catch(e => {
                          console.error(e);
                      });
                    }

                },
          })

        },


        adLoad() {
          // console.log('Banner 广告加载成功')
        },
        adError(err) {
          // console.error('Banner 广告加载失败', err)
        },
        adClose() {
          // console.log('Banner 广告关闭')
        }



    });
}();
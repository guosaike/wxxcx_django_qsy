var app = getApp()
Page({
    data: {
      banner_ad: "",
      byong: [
        'https://pic.imgdb.cn/item/654464a4c458853aef12505e.png',
        'https://pic.imgdb.cn/item/654464a4c458853aef12505e.png',
        'https://pic.imgdb.cn/item/654464a4c458853aef12505e.png',
      ],
    },
    onLoad(o) {
      this.gg_ad()
    },
    gg_ad() {
      let b = this;
      wx.request({
        url: app.globalData.default + '/api/gg_ad/',
            header: {
                "content-type": "application/json"
            },
            success: (res) =>{
              // console.log(res.data.llz[0]),
              b.setData({
                banner_ad: res.data.llz[0],
              })

            },
      })

    },
    onReady() {},
    onShow() {},
    onHide() {},
    onUnload() {},
    onPullDownRefresh() {},
    onReachBottom() {},
    onShareAppMessage() {}
});
var app = getApp()
Page({
    data: {
        isaddmyxcx: 1,
        image: "",
        video: "",
        title: "",
        tuji: [],
        openSettingBtnHidden: !0,
        video_ad: "",
    },
    close() {
        this.setData({
            isaddmyxcx: 0
        });
    },
    onStartDownload() {
        let e = this;
        wx.getSetting({
            success: o => {
                void 0 === o.authSetting["scope.writePhotosAlbum"] ? wx.authorize({
                    scope: "scope.writePhotosAlbum",
                    success: () => {
                        console.log("打开了授权"), e.downloadVideo();
                    },
                    fail: e => {
                        console.log("授权失败:", e);
                    }
                }) : o.authSetting["scope.writePhotosAlbum"] ? e.downloadVideo() : wx.openSetting({
                    success: o => {
                        console.log("openSetting成功回调:res", o), o.authSetting["scope.writePhotosAlbum"] && (console.log("授权了"), 
                        e.downloadVideo());
                    },
                    fail: e => {}
                });
            }
        });
    },
    downloadVideo() {
        wx.downloadFile({
            url: this.data.video,
            filePath: wx.env.USER_DATA_PATH + "/myvideoname.mp4",
            header: {
                "Content-Type": "video/mp4"
            },
            success: e => {
                console.log("downloadFile成功回调res:", e), wx.hideLoading();
                let o = e.filePath, t = wx.getFileSystemManager();
                wx.saveVideoToPhotosAlbum({
                    filePath: o,
                    success: e => {
                        wx.showToast({
                            title: "视频保存成功",
                            duration: 1e3,
                            icon: "none"
                        }), t.unlink({
                            filePath: wx.env.USER_DATA_PATH + "/myvideoname.mp4"
                        });
                    },
                    fail: e => {
                        t.unlink({
                            filePath: wx.env.USER_DATA_PATH + "/myvideoname.mp4"
                        }), wx.showToast({
                            title: "视频保存失败",
                            duration: 3e3,
                            icon: "none"
                        });
                    },
                    complete() {
                        wx.hideLoading();
                    }
                });
            },
            fail(e) {
                console.log("失败e", e), wx.showToast({
                    title: "视频保存失败",
                    duration: 3e3,
                    icon: "none"
                });
            },
            complete() {}
        });
    },
    downloadImg() {
        let e = this;
        wx.getSetting({
            success(o) {
                o.authSetting["scope.writePhotosAlbum"] ? e.saveImgToLocal() : wx.authorize({
                    scope: "scope.writePhotosAlbum",
                    success() {
                        e.saveImgToLocal();
                    },
                    fail() {
                        e.setData({
                            openSettingBtnHidden: !1
                        });
                    }
                });
            }
        });
    },

    // 下载一张图片方法
    // saveImgToLocal: function(e) {
    //     let o = this.data.tuji[0];
    //     wx.downloadFile({
    //         url: o,
    //         success: function(e) {
    //             console.log(e), wx.saveImageToPhotosAlbum({
    //                 filePath: e.tempFilePath,
    //                 success: function(e) {
    //                     wx.showToast({
    //                         title: "保存成功",
    //                         icon: "success",
    //                         duration: 2e3
    //                     });
    //                 }
    //             });
    //         }
    //     });
    // },

    // 数组递归方法下载全部图片（本质利用索引）
    // 保存图片的递归函数
    //   saveImgToLocal: function(index = 0) {
    //     wx.getImageInfo({
    //       src: this.data.tuji[index],
    //       success(res) {
    //         saveImg(res.path).then(() => {
    //           if (index + 1 < tuji.length) {
    //             saveImgToLocal(index + 1)
    //           } else {
    //             console.log('图片保存成功')
    //           }
    //         }).catch(() => {
    //           console.log('图片保存失败')
    //         })
    //       }
    //     })
    //   },

    // 将图片保存到相册
    // saveImg: function(filepath) {
    //   return new Promise((resolve, reject) => {
    //     wx.saveImageToPhotosAlbum({
    //       filePath: filepath,
    //       success() {
    //         resolve()
    //       },
    //       fail() {
    //         reject()
    //       }
    //     })
    //   })
    // },


    saveImgToLocal() {
      var a = this
      a.queue(a.data.tuji)
      .then(res => {
          wx.hideLoading()
          wx.showToast({
           title: '下载完成'
          })
         }).catch(err => {
          wx.hideLoading()
          console.log(err)
         })
       },
     // 队列
     queue(urls) {
      let promise = Promise.resolve()
      urls.forEach((url, index) => {
       promise = promise.then(() => {
        return this.download(url)
       })
      })
      return promise
     },
     // 下载
     download(url) {
      return new Promise((resolve, reject) => {
       wx.downloadFile({
        url: url,
        success: function(res) {
         var temp = res.tempFilePath
         wx.saveImageToPhotosAlbum({
          filePath: temp,
          success: function(res) {
           resolve(res)
          },
          fail: function(err) {
           reject(res)
          }
         })
        },
        fail: function(err) {
         reject(err)
        }
       })
      })
     },






    handleSetting: function(e) {
        let o = this;
        e.detail.authSetting["scope.writePhotosAlbum"] ? o.setData({
            openSettingBtnHidden: !0
        }) : o.setData({
            openSettingBtnHidden: !1
        });
    },
    copyBtn(e) {
        let o = e.target.dataset.copytxt;
        wx.setClipboardData({
            data: o,
            success: function(e) {
                wx.showToast({
                    title: "复制成功",
                    icon: "none",
                    mask: "true"
                });
            }
        });
    },
    onLoad(e) {
        let o = this;
        this.getOpenerEventChannel().on("acceptDataFromOpenerPage", function(e) {
            console.log(e,111111111111111111),
             o.setData({
                image: e.data.fengmian,
                video: e.data.url,
                title: e.data.biaoti,
                tuji: e.data.url
            });
        });
    },
    onReady() {},
    onShow() {},
    onHide() {},
    onUnload() {},
    onPullDownRefresh() {},
    onReachBottom() {},
    onShareAppMessage() {}
});
from django.contrib import admin
from django.urls import path,include
from . import views

urlpatterns = [

    # 调用去水印接口
    path('qsy/', views.qsy),
    # django后端 小程序修改去水印接口
    path('akqsy/', views.akqsy, name='akqsy'),

    # 小程序调用轮播图接口
    path('lbt/', views.lbt, name='lbt'),
    # django后端 小程序查看轮播图接口
    path('selectlbt/', views.selectlbt, name='selectlbt'),
    # django后端 小程序修改轮播图接口
    path('editlbt/<int:pk>/', views.editlbt, name='editlbt'),

    # 小程序调用公告接口
    path('gg/', views.gg, name='gg'),
    # django后端 小程序修改公告接口
    path('editgg/', views.editgg, name='editgg'),

    # 小程序调用广告接口
    path('gg_ad/', views.gg_ad, name='gg_ad'),
    # django后端 小程序修改广告接口
    path('editggad/', views.editggad, name='editggad'),
]

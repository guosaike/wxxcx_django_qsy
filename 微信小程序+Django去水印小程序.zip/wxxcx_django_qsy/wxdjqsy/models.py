from django.contrib.auth.models import AbstractUser
from django.db import models
# Create your models here.


# 用户表
class UserInfo(AbstractUser):
    # user_name = models.CharField(u'用户名',max_length=30)
    # user_pass = models.CharField(u'密码',max_length=80,blank=True,null=True,default="")
    user_email = models.EmailField(verbose_name='邮箱',max_length=60)
    phone = models.BigIntegerField(verbose_name='手机号', null=True, blank=True)
    create_time = models.DateField(auto_now_add=True)
    # user_qsy = models.OneToOneField(to='qsy',related_name='user_qsy',on_delete=models.CASCADE)



# 轮播图
class lbt(models.Model):
    ipaddr = models.CharField(max_length=255,default='https://pic.imgdb.cn/item/654464a4c458853aef12505e.png')


class gg(models.Model):
    gg = models.CharField(max_length=255,default='这是一条小程序和Django的开发公告')


class qsy(models.Model):
    jiekoudizhi = models.CharField(max_length=255,default='')
    qsyuid = models.CharField(max_length=255,default='')
    qsykey = models.CharField(max_length=255,default='')


class llz(models.Model):
    banner_ad = models.CharField(max_length=255,default='')
    video_ad = models.CharField(max_length=255,default='')
    cp_ad = models.CharField(max_length=255,default='')
    jl_ad = models.CharField(max_length=255,default='')